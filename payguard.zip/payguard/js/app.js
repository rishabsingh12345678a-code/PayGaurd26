/**
 * PayGuard – Main Application Logic
 * Real-time scoring simulation + Dashboard
 */

(function () {
  "use strict";

  // ========== STATE ==========
  const state = {
    transactions: [],
    alerts: [],
    isStreaming: true,
    streamInterval: null,
    totalProcessed: 0,
    fraudCaught: 0,
    falsePositives: 0,
    truePositives: 0,
    falseNegatives: 0,
    trueNegatives: 0,
    latencySum: 0,
    charts: {},
    network: null,
    feedbackLog: []
  };

  // ========== DOM HELPERS ==========
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  function formatINR(n) {
    return "₹" + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 0 });
  }

  function formatTime(ts) {
    return new Date(ts).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  }

  function riskClass(score) {
    if (score >= 72) return "risk-high";
    if (score >= 42) return "risk-med";
    return "risk-low";
  }

  function actionBadge(action) {
    const map = {
      ALLOW: "badge-allow",
      CHALLENGE: "badge-challenge",
      BLOCK: "badge-block"
    };
    return `<span class="badge ${map[action] || ""}">${action}</span>`;
  }

  // ========== TOAST ==========
  function showToast(msg, type = "success") {
    const t = document.createElement("div");
    t.className = `toast ${type}`;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3200);
  }

  // ========== UPDATE KPIs ==========
  function updateKPIs() {
    const total = state.totalProcessed || 1;
    const precision = state.truePositives / (state.truePositives + state.falsePositives || 1);
    const recall = state.truePositives / (state.truePositives + state.falseNegatives || 1);
    const fpr = state.falsePositives / (state.falsePositives + state.trueNegatives || 1);
    const avgLatency = state.totalProcessed ? (state.latencySum / state.totalProcessed).toFixed(1) : 0;

    $("#kpi-total").textContent = state.totalProcessed.toLocaleString();
    $("#kpi-fraud").textContent = state.fraudCaught;
    $("#kpi-precision").textContent = (precision * 100).toFixed(1) + "%";
    $("#kpi-recall").textContent = (recall * 100).toFixed(1) + "%";
    $("#kpi-latency").textContent = avgLatency + " ms";
    $("#kpi-fpr").textContent = (fpr * 100).toFixed(2) + "%";

    // Sub texts
    $("#kpi-fraud-sub").textContent = `${state.alerts.length} active alerts`;
  }

  // ========== TRANSACTION FEED ==========
  function renderTransaction(txn) {
    const feed = $("#txn-feed");
    const item = document.createElement("div");
    item.className = "txn-item";
    item.innerHTML = `
      <div class="txn-amount">${formatINR(txn.amount)}</div>
      <div>
        <div>${txn.senderName.split(" ")[0]} → ${txn.receiverName.split(" ")[0]}</div>
        <div class="txn-meta">${txn.type} • ${formatTime(txn.timestamp)}</div>
      </div>
      <div class="risk-score ${riskClass(txn.riskScore)}">${txn.riskScore}</div>
      <div>${actionBadge(txn.action)}</div>
    `;
    feed.insertBefore(item, feed.firstChild);

    // Keep only last 40
    while (feed.children.length > 40) {
      feed.removeChild(feed.lastChild);
    }
  }

  // ========== ALERTS ==========
  function addAlert(txn) {
    if (txn.action === "ALLOW") return;

    const alert = {
      id: txn.id,
      txn,
      timestamp: Date.now(),
      status: "open" // open | confirmed | dismissed
    };
    state.alerts.unshift(alert);
    renderAlerts();
  }

  function renderAlerts() {
    const list = $("#alert-list");
    list.innerHTML = "";

    const openAlerts = state.alerts.filter(a => a.status === "open").slice(0, 12);

    if (openAlerts.length === 0) {
      list.innerHTML = `<div style="text-align:center;color:var(--text-muted);padding:2rem;">No active high-risk alerts</div>`;
      return;
    }

    openAlerts.forEach(alert => {
      const txn = alert.txn;
      const el = document.createElement("div");
      el.className = "alert-item";
      el.dataset.id = alert.id;

      el.innerHTML = `
        <div class="alert-top">
          <div>
            <div class="alert-title">${txn.fraudType ? txn.fraudType.replace("_", " ").toUpperCase() : "HIGH RISK"} • ${formatINR(txn.amount)}</div>
            <div class="txn-meta" style="margin-top:0.25rem;">
              ${txn.senderName} → ${txn.receiverName} • Score: <strong class="${riskClass(txn.riskScore)}">${txn.riskScore}</strong>
            </div>
          </div>
          ${actionBadge(txn.action)}
        </div>
        <div class="alert-reasons">
          <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:0.5rem;">Why this was flagged:</div>
          ${txn.explanations.map(r => `<div class="reason-item">${r}</div>`).join("")}
          <div class="alert-actions">
            <button class="btn btn-sm btn-success" onclick="PayGuardApp.feedback('${alert.id}', 'tp')">Confirm Fraud</button>
            <button class="btn btn-sm btn-danger" onclick="PayGuardApp.feedback('${alert.id}', 'fp')">False Positive</button>
            <button class="btn btn-sm btn-ghost" onclick="PayGuardApp.dismiss('${alert.id}')">Dismiss</button>
          </div>
        </div>
      `;

      el.addEventListener("click", (e) => {
        if (e.target.tagName === "BUTTON") return;
        el.classList.toggle("expanded");
      });

      list.appendChild(el);
    });
  }

  // ========== FEEDBACK ==========
  function feedback(alertId, type) {
    const alert = state.alerts.find(a => a.id === alertId);
    if (!alert) return;

    alert.status = "closed";
    if (type === "tp") {
      showToast("Marked as True Positive – model feedback recorded", "success");
      state.feedbackLog.push({ id: alertId, label: "fraud", ts: Date.now() });
    } else {
      showToast("Marked as False Positive – threshold may adapt", "warning");
      state.feedbackLog.push({ id: alertId, label: "legit", ts: Date.now() });
      // Simulate adaptive threshold (slightly lower sensitivity)
    }
    renderAlerts();
    updateKPIs();
  }

  function dismiss(alertId) {
    const alert = state.alerts.find(a => a.id === alertId);
    if (alert) alert.status = "dismissed";
    renderAlerts();
  }

  // ========== SCORING + METRICS ==========
  function processTransaction(txn) {
    const t0 = performance.now();
    const scored = window.PayGuardData.scoreTransaction(txn);
    Object.assign(txn, scored);
    const latency = performance.now() - t0;

    state.latencySum += latency;
    state.totalProcessed++;
    state.transactions.unshift(txn);

    // Confusion matrix simulation
    const predictedFraud = txn.action !== "ALLOW";
    if (txn.isFraud && predictedFraud) {
      state.truePositives++;
      state.fraudCaught++;
    } else if (!txn.isFraud && predictedFraud) {
      state.falsePositives++;
    } else if (txn.isFraud && !predictedFraud) {
      state.falseNegatives++;
    } else {
      state.trueNegatives++;
    }

    renderTransaction(txn);
    if (predictedFraud) addAlert(txn);

    // Keep memory light
    if (state.transactions.length > 300) state.transactions.pop();

    updateKPIs();
    updateCharts();
  }

  // ========== STREAMING ==========
  function startStream() {
    if (state.streamInterval) return;
    state.isStreaming = true;
    $("#stream-status").textContent = "LIVE";
    $(".pulse").style.background = "var(--success)";

    state.streamInterval = setInterval(() => {
      if (!state.isStreaming) return;
      const txn = window.PayGuardData.generateTransaction();
      processTransaction(txn);
    }, 1100); // ~1 txn per second for demo
  }

  function stopStream() {
    state.isStreaming = false;
    clearInterval(state.streamInterval);
    state.streamInterval = null;
    $("#stream-status").textContent = "PAUSED";
    $(".pulse").style.background = "var(--warning)";
  }

  function toggleStream() {
    if (state.isStreaming) stopStream();
    else startStream();
  }

  // ========== CHARTS ==========
  function initCharts() {
    // Risk distribution
    const riskCtx = $("#chart-risk").getContext("2d");
    state.charts.risk = new Chart(riskCtx, {
      type: "bar",
      data: {
        labels: ["0-20", "21-40", "41-60", "61-80", "81-100"],
        datasets: [{
          label: "Transactions",
          data: [0, 0, 0, 0, 0],
          backgroundColor: [
            "rgba(16, 185, 129, 0.7)",
            "rgba(59, 130, 246, 0.7)",
            "rgba(245, 158, 11, 0.7)",
            "rgba(249, 115, 22, 0.7)",
            "rgba(239, 68, 68, 0.7)"
          ],
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, grid: { color: "rgba(45,58,79,0.5)" }, ticks: { color: "#94a3b8" } },
          x: { grid: { display: false }, ticks: { color: "#94a3b8" } }
        }
      }
    });

    // Precision / Recall over time (simulated rolling)
    const prCtx = $("#chart-pr").getContext("2d");
    state.charts.pr = new Chart(prCtx, {
      type: "line",
      data: {
        labels: [],
        datasets: [
          {
            label: "Precision",
            data: [],
            borderColor: "#3b82f6",
            backgroundColor: "rgba(59,130,246,0.1)",
            tension: 0.3,
            fill: true
          },
          {
            label: "Recall",
            data: [],
            borderColor: "#10b981",
            backgroundColor: "rgba(16,185,129,0.1)",
            tension: 0.3,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: "#94a3b8" } }
        },
        scales: {
          y: { min: 0, max: 1, grid: { color: "rgba(45,58,79,0.5)" }, ticks: { color: "#94a3b8" } },
          x: { grid: { display: false }, ticks: { color: "#94a3b8", maxTicksLimit: 8 } }
        }
      }
    });

    // Action distribution
    const actionCtx = $("#chart-actions").getContext("2d");
    state.charts.actions = new Chart(actionCtx, {
      type: "doughnut",
      data: {
        labels: ["Allow", "Challenge", "Block"],
        datasets: [{
          data: [0, 0, 0],
          backgroundColor: ["#10b981", "#f59e0b", "#ef4444"],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: "bottom", labels: { color: "#94a3b8", padding: 16 } }
        }
      }
    });
  }

  function updateCharts() {
    // Risk buckets
    const buckets = [0, 0, 0, 0, 0];
    let allow = 0, challenge = 0, block = 0;

    state.transactions.slice(0, 150).forEach(t => {
      if (t.riskScore <= 20) buckets[0]++;
      else if (t.riskScore <= 40) buckets[1]++;
      else if (t.riskScore <= 60) buckets[2]++;
      else if (t.riskScore <= 80) buckets[3]++;
      else buckets[4]++;

      if (t.action === "ALLOW") allow++;
      else if (t.action === "CHALLENGE") challenge++;
      else block++;
    });

    state.charts.risk.data.datasets[0].data = buckets;
    state.charts.risk.update("none");

    state.charts.actions.data.datasets[0].data = [allow, challenge, block];
    state.charts.actions.update("none");

    // Rolling precision/recall every ~8 txns
    if (state.totalProcessed % 8 === 0) {
      const p = state.truePositives / (state.truePositives + state.falsePositives || 1);
      const r = state.truePositives / (state.truePositives + state.falseNegatives || 1);

      const labels = state.charts.pr.data.labels;
      labels.push(state.totalProcessed);
      if (labels.length > 12) {
        labels.shift();
        state.charts.pr.data.datasets[0].data.shift();
        state.charts.pr.data.datasets[1].data.shift();
      }
      state.charts.pr.data.datasets[0].data.push(p);
      state.charts.pr.data.datasets[1].data.push(r);
      state.charts.pr.update("none");
    }
  }

  // ========== NETWORK GRAPH ==========
  function initNetwork() {
    const container = $("#network-graph");
    const data = window.PayGuardData.getGraphData(30);

    const options = {
      nodes: {
        shape: "dot",
        size: 16,
        font: { size: 12, color: "#e2e8f0" },
        borderWidth: 2,
        borderWidthSelected: 3
      },
      edges: {
        width: 1.5,
        smooth: { type: "continuous" },
        arrows: { to: { enabled: true, scaleFactor: 0.5 } }
      },
      physics: {
        stabilization: { iterations: 80 },
        barnesHut: { gravitationalConstant: -3000, springLength: 95 }
      },
      interaction: { hover: true, tooltipDelay: 120 }
    };

    state.network = new vis.Network(container, data, options);
  }

  function refreshNetwork() {
    if (!state.network) return;
    const data = window.PayGuardData.getGraphData(32);
    state.network.setData(data);
  }

  // ========== INJECT FRAUD DEMO ==========
  function injectFraud(type) {
    const txn = window.PayGuardData.generateTransaction(type);
    processTransaction(txn);
    showToast(`Injected ${type.replace("_", " ")} pattern`, "danger");
    setTimeout(refreshNetwork, 400);
  }

  // ========== INIT ==========
  function init() {
    // Hide loader
    setTimeout(() => {
      const loader = $(".loading-overlay");
      if (loader) loader.classList.add("hidden");
    }, 900);

    // Seed some history
    const history = window.PayGuardData.generateHistoricalBatch(60);
    history.forEach(txn => {
      state.transactions.push(txn);
      state.totalProcessed++;
      state.latencySum += randomFloat(1.5, 6);

      const predictedFraud = txn.action !== "ALLOW";
      if (txn.isFraud && predictedFraud) {
        state.truePositives++;
        state.fraudCaught++;
      } else if (!txn.isFraud && predictedFraud) state.falsePositives++;
      else if (txn.isFraud && !predictedFraud) state.falseNegatives++;
      else state.trueNegatives++;

      if (predictedFraud) {
        state.alerts.push({
          id: txn.id,
          txn,
          timestamp: txn.timestamp,
          status: Math.random() > 0.6 ? "open" : "closed"
        });
      }
    });

    // Render initial feed
    history.slice(0, 25).reverse().forEach(renderTransaction);

    initCharts();
    updateCharts();
    updateKPIs();
    renderAlerts();
    initNetwork();

    // Start live stream
    startStream();

    // Refresh graph periodically
    setInterval(refreshNetwork, 12000);

    // Event listeners
    $("#btn-toggle-stream")?.addEventListener("click", toggleStream);
    $("#btn-inject-mule")?.addEventListener("click", () => injectFraud("mule_chain"));
    $("#btn-inject-collect")?.addEventListener("click", () => injectFraud("collect_scam"));
    $("#btn-inject-velocity")?.addEventListener("click", () => injectFraud("velocity"));
    $("#btn-refresh-graph")?.addEventListener("click", refreshNetwork);

    // Smooth scroll nav
    $$(".nav-links a").forEach(a => {
      a.addEventListener("click", (e) => {
        e.preventDefault();
        const id = a.getAttribute("href");
        if (id && id.startsWith("#")) {
          document.querySelector(id)?.scrollIntoView({ behavior: "smooth" });
          $$(".nav-links a").forEach(x => x.classList.remove("active"));
          a.classList.add("active");
        }
      });
    });
  }

  // Expose for inline handlers
  window.PayGuardApp = {
    feedback,
    dismiss,
    injectFraud,
    toggleStream
  };

  // Helper used in init
  function randomFloat(min, max) {
    return Math.random() * (max - min) + min;
  }

  // Boot
  document.addEventListener("DOMContentLoaded", init);
})();
