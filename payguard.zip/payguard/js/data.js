/**
 * PayGuard – Synthetic Transaction Generator
 * Injects realistic fraud patterns for demo
 */

const FIRST_NAMES = ["Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan",
  "Ananya", "Aadhya", "Pari", "Anika", "Navya", "Diya", "Myra", "Sara", "Ira", "Aarohi",
  "Rahul", "Priya", "Amit", "Sneha", "Vikram", "Neha", "Rajesh", "Pooja", "Suresh", "Kavita"];

const LAST_NAMES = ["Sharma", "Verma", "Patel", "Singh", "Kumar", "Gupta", "Reddy", "Nair", "Joshi", "Mehta",
  "Iyer", "Chopra", "Malhotra", "Agarwal", "Banerjee", "Desai", "Khan", "Pillai", "Rao", "Saxena"];

const CITIES = ["Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad", "Jaipur", "Lucknow"];

const MERCHANTS = ["Swiggy", "Zomato", "Amazon", "Flipkart", "Uber", "Ola", "IRCTC", "BookMyShow", "PhonePe Merchant", "Paytm Store", "Local Kirana", "Petrol Pump", "Electricity Board", "Gas Agency"];

function randomChoice(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min, max, decimals = 2) {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function generateVPA(name) {
  const clean = name.toLowerCase().replace(/\s+/g, "");
  const providers = ["oksbi", "okhdfcbank", "okicici", "okaxis", "paytm", "ybl", "apl", "axl"];
  return `${clean}${randomInt(10, 99)}@${randomChoice(providers)}`;
}

function generateAccountId() {
  return "ACC" + String(randomInt(100000, 999999));
}

// Global state for users and graph
const USERS = {};
const GRAPH_EDGES = [];
let TXN_COUNTER = 1000;
let FRAUD_INJECTION_RATE = 0.08; // 8% fraud for demo visibility (real is ~0.1%)

function getOrCreateUser(id = null) {
  if (id && USERS[id]) return USERS[id];

  const first = randomChoice(FIRST_NAMES);
  const last = randomChoice(LAST_NAMES);
  const name = `${first} ${last}`;
  const userId = id || generateAccountId();

  const user = {
    id: userId,
    name,
    vpa: generateVPA(first),
    city: randomChoice(CITIES),
    avgAmount: randomFloat(200, 3500),
    stdAmount: randomFloat(100, 800),
    dailyTxnCount: randomInt(2, 12),
    riskHistory: [],
    isMule: false,
    isCompromised: false,
    createdAt: Date.now() - randomInt(30, 400) * 86400000,
    lastActive: Date.now() - randomInt(0, 48) * 3600000,
    deviceTrust: randomFloat(0.6, 1.0),
    knownBeneficiaries: new Set()
  };

  USERS[userId] = user;
  return user;
}

// Pre-seed some normal users and a few mule candidates
function seedUsers(count = 40) {
  for (let i = 0; i < count; i++) {
    getOrCreateUser();
  }
  // Mark a few potential mules
  const userIds = Object.keys(USERS);
  for (let i = 0; i < 5; i++) {
    const u = USERS[userIds[randomInt(0, userIds.length - 1)]];
    u.isMule = true;
    u.avgAmount = randomFloat(8000, 25000);
  }
}

seedUsers(50);

/**
 * Generate one realistic transaction
 * With probability FRAUD_INJECTION_RATE, inject a fraud pattern
 */
function generateTransaction(forceFraudType = null) {
  TXN_COUNTER++;
  const now = Date.now();

  let sender, receiver, amount, type, isFraud = false, fraudType = null, reasons = [];

  const fraudRoll = forceFraudType || (Math.random() < FRAUD_INJECTION_RATE);

  if (fraudRoll) {
    // Choose fraud type
    const types = forceFraudType ? [forceFraudType] : ["mule_chain", "collect_scam", "velocity", "ato"];
    fraudType = randomChoice(types);
    isFraud = true;

    if (fraudType === "mule_chain") {
      // Rapid hop through mule accounts
      const mules = Object.values(USERS).filter(u => u.isMule);
      sender = mules.length ? randomChoice(mules) : getOrCreateUser();
      receiver = mules.length > 1 ? randomChoice(mules.filter(m => m.id !== sender.id)) : getOrCreateUser();
      amount = randomFloat(15000, 49000);
      type = "P2P";
      reasons = [
        "High-value transfer between known mule-like accounts",
        "Accounts show rapid sequential cash-out pattern",
        "Low historical relationship strength",
        "Amount significantly above sender's normal behaviour"
      ];
    } else if (fraudType === "collect_scam") {
      sender = getOrCreateUser(); // victim
      receiver = getOrCreateUser(); // scammer
      receiver.isCompromised = true;
      amount = randomFloat(500, 5000);
      type = "COLLECT";
      reasons = [
        "Incoming collect request from newly created / low-trust VPA",
        "Scammer VPA has high volume of collect requests in short window",
        "No prior transaction history between parties",
        "Request amount is round and social-engineering typical"
      ];
    } else if (fraudType === "velocity") {
      sender = getOrCreateUser();
      sender.dailyTxnCount = randomInt(25, 60); // spike
      receiver = getOrCreateUser();
      amount = randomFloat(2000, 12000);
      type = "P2P";
      reasons = [
        "Sudden velocity spike: >20 transactions in last 60 minutes",
        "Deviation from user's historical daily pattern",
        "Multiple new beneficiaries in short time",
        "Possible account takeover or automated draining"
      ];
    } else { // ato
      sender = getOrCreateUser();
      sender.deviceTrust = randomFloat(0.1, 0.4);
      receiver = getOrCreateUser();
      amount = randomFloat(8000, 35000);
      type = "P2P";
      reasons = [
        "Device / location mismatch with user's usual pattern",
        "Login from new device followed by high-value transfer",
        "Beneficiary is new and high-risk",
        "Behavioural biometrics score very low"
      ];
    }
  } else {
    // Normal transaction
    sender = getOrCreateUser();
    const isMerchant = Math.random() < 0.55;
    if (isMerchant) {
      receiver = {
        id: "MERCH" + randomInt(1000, 9999),
        name: randomChoice(MERCHANTS),
        vpa: randomChoice(MERCHANTS).toLowerCase().replace(/\s/g, "") + "@ybl",
        city: randomChoice(CITIES)
      };
      type = "P2M";
      amount = randomFloat(50, Math.min(sender.avgAmount * 1.8, 8000));
    } else {
      receiver = getOrCreateUser();
      type = "P2P";
      amount = Math.max(10, randomFloat(sender.avgAmount * 0.3, sender.avgAmount * 1.5));
    }
    reasons = [];
  }

  // Record edge for graph
  if (type !== "P2M") {
    GRAPH_EDGES.push({
      from: sender.id,
      to: receiver.id,
      amount,
      timestamp: now,
      isFraud
    });
  }

  // Update sender profile lightly
  if (USERS[sender.id]) {
    USERS[sender.id].lastActive = now;
    USERS[sender.id].knownBeneficiaries.add(receiver.id);
  }

  const txn = {
    id: `TXN${TXN_COUNTER}`,
    timestamp: now,
    senderId: sender.id,
    senderName: sender.name,
    senderVpa: sender.vpa || sender.id,
    receiverId: receiver.id,
    receiverName: receiver.name,
    receiverVpa: receiver.vpa || receiver.id,
    amount: parseFloat(amount.toFixed(2)),
    type,
    city: sender.city || randomChoice(CITIES),
    isFraud,
    fraudType,
    rawReasons: reasons,
    // Will be filled by scoring engine
    riskScore: 0,
    action: "ALLOW",
    explanations: []
  };

  return txn;
}

/**
 * Simple explainable risk scoring engine
 * Returns score 0-100 + explanations
 */
function scoreTransaction(txn) {
  let score = 0;
  const explanations = [];

  const sender = USERS[txn.senderId];
  const amount = txn.amount;

  // 1. Amount anomaly
  if (sender) {
    const z = Math.abs(amount - sender.avgAmount) / (sender.stdAmount || 500);
    if (z > 2.5) {
      score += 25;
      explanations.push(`Amount ₹${amount.toLocaleString('en-IN')} is ${z.toFixed(1)}σ away from user's average (₹${sender.avgAmount.toFixed(0)})`);
    } else if (z > 1.5) {
      score += 12;
      explanations.push(`Amount moderately higher than usual spending pattern`);
    }
  }

  // 2. High absolute amount
  if (amount > 25000) {
    score += 18;
    explanations.push(`High-value transaction (₹${amount.toLocaleString('en-IN')})`);
  } else if (amount > 10000) {
    score += 8;
  }

  // 3. Fraud type boost (simulating model detection)
  if (txn.isFraud) {
    score += 35 + randomInt(5, 20);
    explanations.push(...txn.rawReasons);
  }

  // 4. New beneficiary
  if (sender && !sender.knownBeneficiaries.has(txn.receiverId) && txn.type === "P2P") {
    score += 10;
    explanations.push("First-time transfer to this beneficiary");
  }

  // 5. Device / trust
  if (sender && sender.deviceTrust < 0.5) {
    score += 20;
    explanations.push("Low device trust score / possible new or emulated device");
  }

  // 6. Collect request extra risk
  if (txn.type === "COLLECT") {
    score += 15;
    explanations.push("Collect-request transactions carry elevated social-engineering risk");
  }

  // 7. Time-based (night activity)
  const hour = new Date(txn.timestamp).getHours();
  if (hour >= 1 && hour <= 5 && amount > 5000) {
    score += 12;
    explanations.push("Unusual late-night high-value activity");
  }

  // Cap and add slight noise
  score = Math.min(98, Math.max(2, score + randomInt(-5, 5)));

  // Decision
  let action = "ALLOW";
  if (score >= 72) action = "BLOCK";
  else if (score >= 42) action = "CHALLENGE";

  // Ensure explanations exist
  if (explanations.length === 0) {
    explanations.push("Transaction matches user's normal behavioural profile");
    explanations.push("No strong anomaly signals detected");
  }

  return {
    riskScore: score,
    action,
    explanations: explanations.slice(0, 5) // top 5
  };
}

/**
 * Generate a batch of historical transactions for charts
 */
function generateHistoricalBatch(count = 200) {
  const batch = [];
  for (let i = 0; i < count; i++) {
    const txn = generateTransaction();
    const scored = scoreTransaction(txn);
    Object.assign(txn, scored);
    batch.push(txn);
  }
  return batch;
}

/**
 * Get current graph data for vis-network
 */
function getGraphData(maxNodes = 35) {
  const nodeMap = new Map();
  const edges = [];

  // Take recent edges
  const recent = GRAPH_EDGES.slice(-120);

  recent.forEach(e => {
    if (!nodeMap.has(e.from)) {
      const u = USERS[e.from] || { name: e.from, isMule: false };
      nodeMap.set(e.from, {
        id: e.from,
        label: u.name.split(" ")[0],
        title: `${u.name}\n${e.from}`,
        color: u.isMule ? "#ef4444" : (u.isCompromised ? "#f59e0b" : "#3b82f6"),
        isMule: u.isMule
      });
    }
    if (!nodeMap.has(e.to)) {
      const u = USERS[e.to] || { name: e.to, isMule: false };
      nodeMap.set(e.to, {
        id: e.to,
        label: u.name ? u.name.split(" ")[0] : e.to.slice(0, 8),
        title: `${u.name || e.to}\n${e.to}`,
        color: u.isMule ? "#ef4444" : (u.isCompromised ? "#f59e0b" : "#10b981"),
        isMule: u.isMule
      });
    }

    edges.push({
      from: e.from,
      to: e.to,
      value: Math.min(10, e.amount / 5000),
      color: e.isFraud ? { color: "#ef4444", highlight: "#f87171" } : { color: "#475569", highlight: "#94a3b8" },
      title: `₹${e.amount.toLocaleString('en-IN')}`
    });
  });

  // Limit nodes
  let nodes = Array.from(nodeMap.values());
  if (nodes.length > maxNodes) {
    // Prefer mules and high degree
    nodes = nodes.slice(0, maxNodes);
  }

  return { nodes, edges };
}

// Export for browser
window.PayGuardData = {
  generateTransaction,
  scoreTransaction,
  generateHistoricalBatch,
  getGraphData,
  USERS,
  GRAPH_EDGES,
  setFraudRate: (r) => { FRAUD_INJECTION_RATE = r; }
};
