# 🛡️ PayGuard: Anomaly Detection for Digital Payments

**Real-time Fraud Monitoring Prototype for Digital Payments (UPI / Wallets / Banks)**

[![Live Demo](https://img.shields.io/badge/Live%20Demo-GitHub%20Pages-blue?style=for-the-badge)](https://YOUR_USERNAME.github.io/payguard)
[![Hackathon](https://img.shields.io/badge/Jagran%20Hackathon%205-Problem%20%2314-orange?style=for-the-badge)]()
[![Tech](https://img.shields.io/badge/Stack-HTML%20%7C%20CSS%20%7C%20JS%20%7C%20Chart.js%20%7C%20vis.js-green?style=for-the-badge)]()

---

## 📌 Problem Overview

Digital payments in India have exploded, but so has fraud:
- Collect-request scams
- Account takeovers
- Mule accounts & rapid cash-out chains
- Coordinated small-value fraud that rules miss

Fraud is extremely rare (<0.1%), yet devastating. Banks need **millisecond decisions** with **explainable alerts** and **network-level detection**.

**PayGuard** is a complete prototype that:
- Ingests a live transaction stream
- Builds behavioural profiles
- Scores risk in real-time
- Detects individual anomalies + suspicious account networks (graph analysis)
- Provides clear investigator evidence
- Shows precision/recall metrics under extreme class imbalance

---

## ✨ Features (MVP)

| Feature | Status |
|---------|--------|
| Streaming transaction ingestion (simulated) | ✅ |
| Behavioural profile per user | ✅ |
| Real-time risk scoring + action suggestion (Allow / Challenge / Block) | ✅ |
| Detection of **2+ fraud types** (Mule Network + Collect Request Scam + Velocity Abuse) | ✅ |
| Suspicious relationship / mule detection (Graph) | ✅ |
| Alert queue with human-readable explanations | ✅ |
| Investigator feedback simulation | ✅ |
| Precision / Recall / FPR dashboard | ✅ |
| Adaptive thresholds & concept drift simulation | ✅ |
| Fully client-side (works offline after load) | ✅ |

---

## 🚀 Live Demo

After deploying to GitHub Pages:

```
https://YOUR_USERNAME.github.io/payguard/
```

---

## 🛠️ How to Deploy on GitHub Pages

1. Create a new repository named `payguard` (or any name)
2. Upload all files from this folder to the root of the repository
3. Go to **Settings → Pages**
4. Source: **Deploy from a branch** → Branch: `main` → Folder: `/ (root)`
5. Wait 1-2 minutes → Your site is live!

---

## 📁 Project Structure

```
payguard/
├── index.html              # Main dashboard
├── css/
│   └── styles.css          # Modern dark theme + responsive
├── js/
│   ├── data.js             # Synthetic transaction generator + fraud injection
│   └── app.js              # Core logic, scoring, UI, charts, graph
├── assets/                 # (optional images/icons)
└── README.md
```

---

## 🧠 Technical Highlights

### Fraud Patterns Injected
1. **Mule Network / Cash-out Chain**: Money hops through 3-5 accounts in < 15 minutes
2. **Collect Request Scam**: High volume of incoming collect requests from new/suspicious VPA
3. **Velocity Abuse**: Sudden spike in transaction count/amount from a quiet account
4. **Account Takeover signals**: Device/location mismatch + unusual amount

### Risk Scoring (Simplified Explainable Model)
- Amount anomaly (z-score vs user history)
- Velocity (txns in last 1h / 24h)
- Graph features (degree, community, path to known bad)
- Time-of-day / behavioural deviation
- New beneficiary risk

**Action**:
- Score < 40 → Allow
- 40–70 → Challenge (OTP / App confirmation)
- > 70 → Block + Alert

### Evaluation Focus
- Extreme class imbalance handled via precision@k and recall at fixed FPR
- No data leakage in synthetic generator
- Latency simulation (client-side < 5ms per txn)

---

## 📊 Tech Stack

- **Frontend**: Vanilla HTML5 + CSS3 + JavaScript (ES6+)
- **Charts**: Chart.js
- **Network Graph**: vis-network
- **Styling**: Custom CSS (dark cyber-security theme)
- **Hosting**: GitHub Pages (100% static)

No backend required for the demo. Perfect for hackathon presentation.

---

## 🔮 Future Scope

- Kafka / Redis Streams real ingestion
- FastAPI + XGBoost / Isolation Forest backend
- NetworkX graph reasoning server
- Federated learning across banks
- Step-up verification UX
- Regulatory reporting automation

---

## 👨‍💻 Built for

**Jagran Hackathon 5 – Innovate Build Solve**  
Problem Set #14 | Domain: Cyber Security | Tags: Fraud Detection, Streaming Analytics, Graph Analysis, Imbalanced Learning

---

## 📄 License

MIT – Free to use, modify and present.

---

**Made with ❤️ for safer digital payments in India**
